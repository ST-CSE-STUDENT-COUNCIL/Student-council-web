"""
활동(Activities) 관련 API 엔드포인트

통합 활동 관리:
- 행사신청 (event)
- 수요조사 (demand_survey)  
- 설문조사 (survey)
- 카톡방 초대 신청 (kakao_invite)
- 공지 (notice)
"""
from fastapi import APIRouter, HTTPException, Depends, status, Query, UploadFile, File, Form, Request
from slowapi import Limiter
from slowapi.util import get_remote_address
from typing import Optional
from datetime import datetime
from app.utils.logger import get_logger

logger = get_logger(__name__)
import math
import json
from app.schemas.activities import (
    ActivityCreateRequest,
    ActivityUpdateRequest,
    ActivityResponse,
    ActivityListItem,
    ActivityListResponse,
    ActivityRegistrationRequest,
    ActivityRegistrationResponse,
    ActivityRegistrationListResponse,
    SurveySubmitRequest,
    SurveyStatsResponse,
    RegistrationStatusUpdateRequest,
    DemandSurveyStatsResponse,
    ErrorResponse,
    AttendanceCheckRequest,
    AttendanceCheckResponse,
    AttendanceInfoResponse,
    AttendanceListResponse,
    AttendanceListItem
)
from app.utils.auth import optional_current_user, require_verified_user, require_admin
from app.utils.r2_storage import (
    upload_file_to_r2,
    delete_file_from_r2,
    generate_presigned_url,
    validate_file_extension,
    get_bucket_url,
    BROAD_ALLOWED_EXTENSIONS
)
from app.database import supabase, get_supabase_admin
import uuid
import os


router = APIRouter(tags=["활동"])
limiter = Limiter(key_func=get_remote_address)


# ============================================================================
# 공개 엔드포인트 (로그인 불필요)
# ============================================================================

@router.get(
    "/activities",
    response_model=ActivityListResponse,
    status_code=status.HTTP_200_OK,
    summary="활동 목록 조회",
    description="활동 목록을 조회합니다. 타입별 필터링 가능합니다.",
    responses={
        200: {"description": "성공"}
    }
)
async def get_activities(
    type_filter: Optional[str] = Query(None, description="활동 타입 필터 (event, demand_survey, survey, kakao_invite, notice)"),
    is_active_only: bool = Query(True, description="활성화된 활동만 조회"),
    page: int = Query(1, ge=1, description="페이지 번호"),
    page_size: int = Query(20, ge=1, le=100, description="페이지당 항목 수"),
    current_user: Optional[dict] = Depends(optional_current_user)
):
    """활동 목록 조회"""
    try:
        # 전체 개수 조회
        count_query = supabase.table("activities").select("id", count="exact")  # type: ignore
        
        if is_active_only:
            count_query = count_query.eq("is_active", True)
        
        count_query = count_query.eq("is_deleted", False)
        
        if type_filter:
            count_query = count_query.eq("type", type_filter)
        
        count_result = count_query.execute()
        total = count_result.count if count_result.count is not None else 0
        
        # 목록 조회
        query = supabase.table("activities")\
            .select("*")\
            .eq("is_deleted", False)\
            .order("created_at", desc=True)
        
        if is_active_only:
            query = query.eq("is_active", True)
        
        if type_filter:
            query = query.eq("type", type_filter)
        
        offset = (page - 1) * page_size
        query = query.range(offset, offset + page_size - 1)
        
        result = query.execute()
        activities_data = result.data if result.data else []
        
        # 응답 데이터 구성
        from datetime import timezone, timedelta
        kst = timezone(timedelta(hours=9))
        items = []
        now = datetime.now(kst)
        
        for activity in activities_data:
            registration_start = datetime.fromisoformat(activity["registration_start"].replace('Z', '+00:00')) if activity.get("registration_start") else None
            registration_end = datetime.fromisoformat(activity["registration_end"].replace('Z', '+00:00')) if activity.get("registration_end") else None
            
            # 신청 가능 여부 판단
            is_registration_open = True
            if registration_start and now < registration_start:
                is_registration_open = False
            if registration_end and now > registration_end:
                is_registration_open = False
            
            # 정원 마감 여부
            is_full = False
            if activity.get("max_capacity") and activity.get("current_count", 0) >= activity["max_capacity"]:
                is_full = True
            
            items.append(ActivityListItem(
                id=activity["id"],
                type=activity["type"],
                title=activity["title"],
                description=activity.get("description"),
                registration_start=registration_start,
                registration_end=registration_end,
                max_capacity=activity.get("max_capacity"),
                current_count=activity.get("current_count", 0),
                thumbnail_url=activity.get("thumbnail_url"),
                is_active=activity["is_active"],
                created_at=datetime.fromisoformat(activity["created_at"].replace('Z', '+00:00')),
                is_registration_open=is_registration_open,
                is_full=is_full
            ))
        
        total_pages = math.ceil(total / page_size) if total and total > 0 else 0
        
        return ActivityListResponse(
            activities=items,
            pagination={
                "page": page,
                "limit": page_size,
                "total": total,
                "total_pages": total_pages
            }
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 목록 조회 실패"
        )


@router.get(
    "/activities/{activity_id}",
    response_model=ActivityResponse,
    status_code=status.HTTP_200_OK,
    summary="활동 상세 조회",
    description="활동 상세 정보를 조회합니다.",
    responses={
        200: {"description": "성공"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
async def get_activity(
    activity_id: int,
    current_user: Optional[dict] = Depends(optional_current_user)
):
    """활동 상세 조회"""
    try:
        # 활동 조회
        result = supabase.table("activities")\
            .select("*")\
            .eq("id", activity_id)\
            .eq("is_deleted", False)\
            .single()\
            .execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="활동을 찾을 수 없습니다"
            )
        
        activity = result.data
        
        # 내 신청 여부 확인 (로그인한 경우)
        is_registered = False
        my_registration_id = None
        
        if current_user:
            reg_result = supabase.table("activity_registrations")\
                .select("id")\
                .eq("activity_id", activity_id)\
                .eq("user_id", current_user["id"])\
                .eq("status", "pending")\
                .execute()
            
            if reg_result.data:
                is_registered = True
                my_registration_id = reg_result.data[0]["id"]
        
        # 활동 이미지 조회
        images_result = supabase.table("activity_images")\
            .select("id, image_url, caption, display_order")\
            .eq("activity_id", activity_id)\
            .order("display_order")\
            .execute()
        
        images = images_result.data if images_result.data else []
        
        return ActivityResponse(
            id=activity["id"],
            type=activity["type"],
            title=activity["title"],
            description=activity.get("description"),
            registration_start=datetime.fromisoformat(activity["registration_start"].replace('Z', '+00:00')) if activity.get("registration_start") else None,
            registration_end=datetime.fromisoformat(activity["registration_end"].replace('Z', '+00:00')) if activity.get("registration_end") else None,
            max_capacity=activity.get("max_capacity"),
            current_count=activity.get("current_count", 0),
            require_membership=activity.get("require_membership", False),
            config=activity.get("config", {}),
            form_fields=activity.get("form_fields", []),
            thumbnail_url=activity.get("thumbnail_url"),
            images=images,
            is_active=activity["is_active"],
            is_anonymous=activity.get("is_anonymous", False),
            created_by=activity.get("created_by"),
            created_at=datetime.fromisoformat(activity["created_at"].replace('Z', '+00:00')),
            updated_at=datetime.fromisoformat(activity["updated_at"].replace('Z', '+00:00')),
            is_registered=is_registered,
            my_registration_id=my_registration_id
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 조회 실패"
        )


# ============================================================================
# 신청 엔드포인트 (회원/비회원 모두 가능)
# ============================================================================

@router.post(
    "/activities/{activity_id}/register/presigned-url",
    summary="활동 신청 첨부 이미지 업로드용 Presigned URL 발급",
    description="활동 신청 시 첨부 이미지 업로드를 위한 Presigned URL 발급 (모든 활동 유형에서 사용 가능)"
)
@limiter.limit("50/minute")
async def get_activity_verification_presigned_url(
    activity_id: int,
    filename: str,
    request: Request
):
    """활동 신청 첨부 이미지 업로드를 위한 Presigned URL 발급 (행사, 수요조사, 설문조사, 카톡방 초대 등 모든 유형)"""
    file_ext = validate_file_extension(filename, BROAD_ALLOWED_EXTENSIONS)
    unique_filename = f"{uuid.uuid4()}{file_ext}"
    file_key = f"activity-{activity_id}/verification/{unique_filename}"
    
    presigned_url = generate_presigned_url(
        bucket_name="event-images",
        file_key=file_key,
        expires_in=300
    )
    
    base_url = get_bucket_url("event-images")
    public_url = f"{base_url}/{file_key}"
    
    return {
        "presigned_url": presigned_url,
        "public_url": public_url,
        "file_key": file_key
    }


@router.post(
    "/activities/{activity_id}/register",
    response_model=ActivityRegistrationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="활동 신청",
    description="활동에 신청합니다. 회원/비회원 모두 가능합니다. 모든 활동 유형에서 verification_image_url로 이미지 첨부 가능.",
    responses={
        201: {"description": "신청 완료"},
        400: {"model": ErrorResponse, "description": "신청 실패 (정원 마감, 중복 신청 등)"},
        401: {"model": ErrorResponse, "description": "인증 필요 (카톡방 초대는 회원만)"}
    }
)
@limiter.limit("600/minute")  # DoS 방지용 (공용 IP 고려하여 넉넉하게)
async def register_for_activity(
    activity_id: int,
    body: ActivityRegistrationRequest,
    request: Request,
    current_user: Optional[dict] = Depends(optional_current_user)
):
    """활동 신청 (회원/비회원, Presigned URL 사용)"""
    try:
        # 활동 정보 조회
        activity_result = supabase.table("activities")\
            .select("type, require_membership, registration_start, registration_end, max_capacity, current_count, is_anonymous")\
            .eq("id", activity_id)\
            .eq("is_deleted", False)\
            .eq("is_active", True)\
            .single()\
            .execute()
        
        if not activity_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="활동을 찾을 수 없습니다"
            )
        
        activity = activity_result.data
        
        # 카톡방 초대는 회원만 가능
        if activity["type"] == "kakao_invite" and not current_user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="카톡방 초대 신청은 로그인이 필요합니다"
            )
        
        # 비회원 신청 시 Turnstile 검증 필수
        if not current_user:
            if not body.turnstile_token:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="비회원 신청은 Turnstile 인증이 필요합니다"
                )
            # Turnstile 검증
            from app.utils.turnstile import verify_turnstile
            await verify_turnstile(token=body.turnstile_token)
            
            # 필수 정보 확인 (is_anonymous=true인 활동만 익명 허용)
            is_anonymous_allowed = activity.get("is_anonymous", False)
            
            if not is_anonymous_allowed and not all([body.name, body.student_id, body.department, body.phone]):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="비회원은 이름, 학번, 학과, 전화번호를 모두 입력해야 합니다"
                )
        
        # 회원 정보 가져오기
        user_id = current_user["id"] if current_user else None
        
        # 더미값 필터링 (프론트에서 보낼 수 있는 임시값들)
        DUMMY_STUDENT_IDS = ["00000000", "0"]
        DUMMY_PHONES = ["01000000000", "010-0000-0000", "01000000000"]
        
        raw_student_id = body.student_id
        raw_phone = body.phone
        
        # 더미값이면 None으로 치환
        if raw_student_id in DUMMY_STUDENT_IDS:
            raw_student_id = None
        if raw_phone in DUMMY_PHONES:
            raw_phone = None
        
        # 익명 활동이면 무조건 개인정보 제거 (프론트에서 임시값을 보내도 무시)
        # student_id=None이어야 DB 유니크 인덱스에 걸리지 않음
        if activity.get("is_anonymous", False):
             name = "익명"
             student_id = None
             department = None
             phone = None
             email = None
        else:
            name = body.name or (current_user.get("name") if current_user else None)
            student_id = raw_student_id or (current_user.get("student_id") if current_user else None)
            department = body.department or (current_user.get("department") if current_user else None)
            phone = raw_phone or (current_user.get("phone") if current_user else None)
            email = body.email or (current_user.get("email") if current_user else None)
        
        # PostgreSQL 함수 호출
        rpc_result = supabase.rpc(
            "register_for_activity",
            {
                "p_activity_id": activity_id,
                "p_user_id": user_id,
                "p_name": name,
                "p_student_id": student_id,
                "p_department": department,
                "p_phone": phone,
                "p_email": email,
                "p_form_responses": body.form_responses,
                "p_verification_image_url": body.verification_image_url,
                "p_kakao_id": body.kakao_id
            }
        ).execute()
        
        if not rpc_result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="신청 처리 실패"
            )
        
        result = rpc_result.data[0]
        
        if not result["success"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result["message"]
            )
        
        # 신청 내역 조회
        registration_result = supabase.table("activity_registrations")\
            .select("*")\
            .eq("id", result["registration_id"])\
            .single()\
            .execute()
        
        registration = registration_result.data
        
        return ActivityRegistrationResponse(
            id=registration["id"],
            activity_id=registration["activity_id"],
            user_id=registration.get("user_id"),
            name=registration.get("name"),
            student_id=registration.get("student_id"),
            department=registration.get("department"),
            phone=registration.get("phone"),
            email=registration.get("email"),
            form_responses=registration.get("form_responses", {}),
            kakao_id=registration.get("kakao_id"),
            verification_image_url=registration.get("verification_image_url"),
            status=registration["status"],
            created_at=datetime.fromisoformat(registration["created_at"].replace('Z', '+00:00'))
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 신청 실패"
        )


@router.delete(
    "/activities/{activity_id}/register",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="활동 신청 취소",
    description="활동 신청을 취소합니다. (로그인 필요)",
    responses={
        204: {"description": "취소 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        404: {"model": ErrorResponse, "description": "신청 내역 없음"}
    }
)
async def cancel_activity_registration(
    activity_id: int,
    current_user: dict = Depends(require_verified_user)
):
    """활동 신청 취소"""
    try:
        # 내 신청 내역 조회
        reg_result = supabase.table("activity_registrations")\
            .select("id")\
            .eq("activity_id", activity_id)\
            .eq("user_id", current_user["id"])\
            .single()\
            .execute()
        
        if not reg_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="신청 내역을 찾을 수 없습니다"
            )
        
        registration_id = reg_result.data["id"]
        
        # PostgreSQL 함수 호출
        rpc_result = supabase.rpc(
            "cancel_activity_registration",
            {
                "p_registration_id": registration_id,
                "p_user_id": current_user["id"]
            }
        ).execute()
        
        if not rpc_result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="취소 처리 실패"
            )
        
        result = rpc_result.data[0]
        
        if not result["success"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result["message"]
            )
        
        return None
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="신청 취소 실패"
        )


# ============================================================================
# 설문조사 제출 엔드포인트
# ============================================================================

@router.post(
    "/activities/{activity_id}/survey",
    status_code=status.HTTP_200_OK,
    summary="설문조사 제출",
    description="설문조사에 응답합니다. (로그인 필요)",
    responses={
        200: {"description": "제출 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
@limiter.limit("10/minute")
async def submit_survey(
    activity_id: int,
    body: SurveySubmitRequest,
    request: Request,
    current_user: Optional[dict] = Depends(optional_current_user)
):
    """설문조사 제출 (회원/비회원)"""
    try:
        # 활동 존재 및 타입 확인
        activity_result = supabase.table("activities")\
            .select("type, is_anonymous")\
            .eq("id", activity_id)\
            .eq("type", "survey")\
            .eq("is_deleted", False)\
            .single()\
            .execute()
        
        if not activity_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="설문조사를 찾을 수 없습니다"
            )
        
        is_anonymous = activity_result.data.get("is_anonymous", True)
        
        # 비회원 처리
        if not current_user:
            # Turnstile 검증
            if not body.turnstile_token:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="비회원 참여는 Turnstile 인증이 필요합니다"
                )
            
            from app.utils.turnstile import verify_turnstile
            await verify_turnstile(token=body.turnstile_token)
            
            # 익명 모드: 이름을 "익명" 처리
            if is_anonymous:
                name = "익명"
                reg_student_id = None
                reg_department = None
                reg_phone = None
                reg_email = None
            else:
                # 기명 모드: 필수 정보 확인
                if not all([body.name, body.student_id]):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="기명 설문조사는 이름과 학번을 입력해야 합니다"
                    )
                name = body.name
                reg_student_id = body.student_id
                reg_department = body.department
                reg_phone = body.phone
                reg_email = body.email
            
            # 신규 등록 (비회원 중복 체크 없음)
            supabase.table("activity_registrations").insert({
                "activity_id": activity_id,
                "user_id": None,
                "name": name,
                "student_id": reg_student_id,
                "department": reg_department,
                "phone": reg_phone,
                "email": reg_email,
                "survey_responses": body.survey_responses,
                "status": "pending"
            }).execute()

        else:
            # 회원 처리 (기존 응답 확인)
            existing = supabase.table("activity_registrations")\
                .select("id")\
                .eq("activity_id", activity_id)\
                .eq("user_id", current_user["id"])\
                .execute()
            
            # 익명 모드일 때 회원도 익명 처리
            if is_anonymous:
                reg_name = "익명"
                reg_student_id = None
                reg_department = None
                reg_phone = None
                reg_email = None
            else:
                reg_name = current_user.get("name")
                reg_student_id = current_user.get("student_id")
                reg_department = current_user.get("department")
                reg_phone = current_user.get("phone")
                reg_email = current_user.get("email")
            
            if existing.data:
                # 업데이트
                supabase.table("activity_registrations")\
                    .update({"survey_responses": body.survey_responses})\
                    .eq("id", existing.data[0]["id"])\
                    .execute()
            else:
                # 신규 등록
                supabase.table("activity_registrations").insert({
                    "activity_id": activity_id,
                    "user_id": current_user["id"],
                    "name": reg_name,
                    "student_id": reg_student_id,
                    "department": reg_department,
                    "phone": reg_phone,
                    "email": reg_email,
                    "survey_responses": body.survey_responses,
                    "status": "pending"
                }).execute()
        
        return {"message": "설문조사가 제출되었습니다"}
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="설문조사 제출 실패"
        )


# ============================================================================
# 관리자 엔드포인트
# ============================================================================

@router.post(
    "/admin/activities",
    response_model=ActivityResponse,
    status_code=status.HTTP_201_CREATED,
    summary="활동 생성 (관리자)",
    description="새로운 활동을 생성합니다. 이미지 업로드 가능 (관리자 권한 필요)",
    responses={
        201: {"description": "생성 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"}
    }
)
async def create_activity(
    body: ActivityCreateRequest,
    current_user: dict = Depends(require_admin)
):
    """활동 생성 (관리자 전용, Presigned URL로 이미지 업로드)"""
    try:
        # 활동 데이터 저장
        activity_data = {
            "type": body.type,
            "title": body.title,
            "description": body.description,
            "registration_start": body.registration_start.isoformat() if body.registration_start else None,
            "registration_end": body.registration_end.isoformat() if body.registration_end else None,
            "max_capacity": body.max_capacity,
            "require_membership": body.require_membership,
            "config": body.config,
            "form_fields": [f.model_dump() for f in body.form_fields],
            "thumbnail_url": body.thumbnail_url,
            "is_active": body.is_active,
            "is_anonymous": body.is_anonymous,
            "created_by": current_user["id"]
        }
        
        admin_supabase = get_supabase_admin()
        result = admin_supabase.table("activities").insert(activity_data).execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="활동 생성 실패"
            )
        
        activity = result.data[0]
        activity_id = activity["id"]
        
        # 이미지 정보 저장 (선택적)
        if body.image_urls:
            for idx, img in enumerate(body.image_urls or []):
                image_data = {
                    'activity_id': activity_id,
                    'image_url': img.get("public_url"),
                    'display_order': idx
                }
                admin_supabase.table('activity_images').insert(image_data).execute()
        
        return ActivityResponse(
            id=activity["id"],
            type=activity["type"],
            title=activity["title"],
            description=activity.get("description"),
            registration_start=datetime.fromisoformat(activity["registration_start"].replace('Z', '+00:00')) if activity.get("registration_start") else None,
            registration_end=datetime.fromisoformat(activity["registration_end"].replace('Z', '+00:00')) if activity.get("registration_end") else None,
            max_capacity=activity.get("max_capacity"),
            current_count=activity.get("current_count", 0),
            require_membership=activity.get("require_membership", False),
            config=activity.get("config", {}),
            form_fields=activity.get("form_fields", []),
            thumbnail_url=activity.get("thumbnail_url"),
            is_active=activity["is_active"],
            is_anonymous=activity.get("is_anonymous", False),
            created_by=activity.get("created_by"),
            created_at=datetime.fromisoformat(activity["created_at"].replace('Z', '+00:00')),
            updated_at=datetime.fromisoformat(activity["updated_at"].replace('Z', '+00:00')),
            is_registered=None,
            my_registration_id=None
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 생성 실패"
        )


@router.patch(
    "/admin/activities/{activity_id}",
    response_model=ActivityResponse,
    status_code=status.HTTP_200_OK,
    summary="활동 수정 (관리자)",
    description="활동 정보를 수정합니다. (관리자 권한 필요)",
    responses={
        200: {"description": "수정 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
async def update_activity(
    activity_id: int,
    body: ActivityUpdateRequest,
    current_user: dict = Depends(require_admin)
):
    """활동 수정 (관리자 전용)"""
    try:
        # 수정 데이터 구성
        update_data = {}
        
        if body.title is not None:
            update_data["title"] = body.title
        if body.description is not None:
            update_data["description"] = body.description
        if body.registration_start is not None:
            update_data["registration_start"] = body.registration_start.isoformat()
        if body.registration_end is not None:
            update_data["registration_end"] = body.registration_end.isoformat()
        if body.max_capacity is not None:
            update_data["max_capacity"] = body.max_capacity
        if body.require_membership is not None:
            update_data["require_membership"] = body.require_membership
        if body.config is not None:
            update_data["config"] = body.config
        if body.form_fields is not None:
            update_data["form_fields"] = [field.model_dump() for field in body.form_fields]
        if body.thumbnail_url is not None:
            update_data["thumbnail_url"] = body.thumbnail_url
        if body.is_active is not None:
            update_data["is_active"] = body.is_active
        if body.is_anonymous is not None:
            update_data["is_anonymous"] = body.is_anonymous
        
        # image_urls가 있으면 check 플래그만 세팅 (아래에서 처리)
        has_image_updates = body.image_urls is not None
        
        if not update_data and not has_image_updates:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="수정할 항목이 없습니다"
            )
        
        admin_supabase = get_supabase_admin()
        
        # 활동 정보 업데이트 (update_data가 있는 경우)
        if update_data:
            result = admin_supabase.table("activities")\
                .update(update_data)\
                .eq("id", activity_id)\
                .eq("is_deleted", False)\
                .execute()
        else:
            # 이미지만 업데이트하는 경우 기존 데이터 조회
            result = admin_supabase.table("activities")\
                .select("*")\
                .eq("id", activity_id)\
                .eq("is_deleted", False)\
                .execute()
        
        # 이미지 URL 업데이트 (기존 삭제 후 새로 추가)
        if has_image_updates:
            # 기존 이미지 삭제
            admin_supabase.table("activity_images")\
                .delete()\
                .eq("activity_id", activity_id)\
                .execute()
            
            # 새 이미지 추가
            for idx, img in enumerate(body.image_urls or []):
                image_data = {
                    'activity_id': activity_id,
                    'image_url': img.get("public_url") or img.get("image_url"),
                    'caption': img.get("caption"),
                    'display_order': idx
                }
                admin_supabase.table("activity_images").insert(image_data).execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="활동을 찾을 수 없습니다"
            )
        
        activity = result.data[0]
        
        return ActivityResponse(
            id=activity["id"],
            type=activity["type"],
            title=activity["title"],
            description=activity.get("description"),
            registration_start=datetime.fromisoformat(activity["registration_start"].replace('Z', '+00:00')) if activity.get("registration_start") else None,
            registration_end=datetime.fromisoformat(activity["registration_end"].replace('Z', '+00:00')) if activity.get("registration_end") else None,
            max_capacity=activity.get("max_capacity"),
            current_count=activity.get("current_count", 0),
            require_membership=activity.get("require_membership", False),
            config=activity.get("config", {}),
            form_fields=activity.get("form_fields", []),
            thumbnail_url=activity.get("thumbnail_url"),
            is_active=activity["is_active"],
            is_anonymous=activity.get("is_anonymous", False),
            created_by=activity.get("created_by"),
            created_at=datetime.fromisoformat(activity["created_at"].replace('Z', '+00:00')),
            updated_at=datetime.fromisoformat(activity["updated_at"].replace('Z', '+00:00')),
            is_registered=None,
            my_registration_id=None
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 수정 실패"
        )


@router.delete(
    "/admin/activities/{activity_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="활동 삭제 (관리자)",
    description="활동을 삭제합니다. (Soft Delete, 관리자 권한 필요)",
    responses={
        204: {"description": "삭제 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
async def delete_activity(
    activity_id: int,
    current_user: dict = Depends(require_admin)
):
    """활동 삭제 (관리자 전용, Soft Delete)"""
    try:
        from datetime import timezone, timedelta
        kst = timezone(timedelta(hours=9))
        result = supabase.table("activities")\
            .update({
                "is_deleted": True,
                "deleted_at": datetime.now(kst).isoformat(),
                "deleted_by": current_user["id"]
            })\
            .eq("id", activity_id)\
            .eq("is_deleted", False)\
            .execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="활동을 찾을 수 없습니다"
            )
        
        return None
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="활동 삭제 실패"
        )


@router.get(
    "/admin/activities/{activity_id}/registrations",
    response_model=ActivityRegistrationListResponse,
    status_code=status.HTTP_200_OK,
    summary="활동 신청자 목록 조회 (관리자)",
    description="활동의 신청자 목록을 조회합니다. (관리자 권한 필요)",
    responses={
        200: {"description": "성공"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"}
    }
)
async def get_activity_registrations(
    activity_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    current_user: dict = Depends(require_admin)
):
    """활동 신청자 목록 조회 (관리자 전용)"""
    try:
        # 전체 개수
        # type: ignore는 count 파라미터의 타입 힌트 오류를 무시합니다
        count_result = supabase.table("activity_registrations").select("id", count="exact").eq("activity_id", activity_id).execute()  # type: ignore
        
        total = count_result.count if count_result.count is not None else 0
        
        # 목록 조회
        offset = (page - 1) * page_size
        result = supabase.table("activity_registrations")\
            .select("*")\
            .eq("activity_id", activity_id)\
            .order("created_at", desc=True)\
            .range(offset, offset + page_size - 1)\
            .execute()
        
        registrations = []
        for reg in result.data:
            registrations.append(ActivityRegistrationResponse(
                id=reg["id"],
                activity_id=reg["activity_id"],
                user_id=reg.get("user_id"),
                name=reg.get("name"),
                student_id=reg.get("student_id"),
                department=reg.get("department"),
                phone=reg.get("phone"),
                email=reg.get("email"),
                form_responses=reg.get("form_responses", {}),
                kakao_id=reg.get("kakao_id"),
                verification_image_url=reg.get("verification_image_url"),
                status=reg["status"],
                created_at=datetime.fromisoformat(reg["created_at"].replace('Z', '+00:00'))
            ))
        
        total_pages = math.ceil(total / page_size) if total and total > 0 else 0
        
        return ActivityRegistrationListResponse(
            registrations=registrations,
            pagination={
                "page": page,
                "limit": page_size,
                "total": total,
                "total_pages": total_pages
            }
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="신청자 목록 조회 실패"
        )


@router.patch(
    "/admin/activities/{activity_id}/registrations/{registration_id}",
    response_model=ActivityRegistrationResponse,
    status_code=status.HTTP_200_OK,
    summary="신청 상태 변경 (관리자)",
    description="활동 신청의 상태를 승인/거절로 변경합니다. (관리자 권한 필요)",
    responses={
        200: {"description": "성공"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "신청 정보 없음"}
    }
)
async def update_registration_status(
    activity_id: int,
    registration_id: int,
    body: RegistrationStatusUpdateRequest,
    current_user: dict = Depends(require_admin)
):
    """신청 상태 변경 (관리자 전용)"""
    try:
        admin_supabase = get_supabase_admin()
        
        # 신청 정보 조회
        existing = admin_supabase.table("activity_registrations")\
            .select("*")\
            .eq("id", registration_id)\
            .eq("activity_id", activity_id)\
            .execute()
        
        if not existing.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="신청 정보를 찾을 수 없습니다"
            )
        
        current_status = existing.data[0].get('status')
        
        # 같은 상태로 변경 시도 시 무시
        if current_status == body.status:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="이미 동일한 상태입니다"
            )
        
        # 상태 업데이트 (이전 상태 조건으로 race condition 방지)
        update_data = {"status": body.status}
        if body.admin_note:
            update_data["admin_note"] = body.admin_note
        
        result = admin_supabase.table("activity_registrations")\
            .update(update_data)\
            .eq("id", registration_id)\
            .eq("status", current_status)\
            .execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="이미 처리된 요청입니다"
            )
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="상태 변경 실패"
            )
        
        reg = result.data[0]
        
        return ActivityRegistrationResponse(
            id=reg["id"],
            activity_id=reg["activity_id"],
            user_id=reg.get("user_id"),
            name=reg.get("name"),
            student_id=reg.get("student_id"),
            department=reg.get("department"),
            phone=reg.get("phone"),
            email=reg.get("email"),
            form_responses=reg.get("form_responses", {}),
            kakao_id=reg.get("kakao_id"),
            verification_image_url=reg.get("verification_image_url"),
            status=reg["status"],
            created_at=datetime.fromisoformat(reg["created_at"].replace('Z', '+00:00'))
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="상태 변경 실패"
        )


@router.post(
    "/admin/activities/presigned-url",
    summary="활동 이미지 업로드용 Presigned URL 발급 (관리자)",
    description="활동 생성/수정 시 이미지 업로드를 위한 Presigned URL을 발급합니다."
)
async def get_admin_activity_presigned_url(
    filename: str,
    current_user: dict = Depends(require_admin)
):
    """관리자용 활동 이미지 Presigned URL 발급"""
    file_ext = validate_file_extension(filename, BROAD_ALLOWED_EXTENSIONS)
    unique_filename = f"{uuid.uuid4()}{file_ext}"
    file_key = f"activities/{unique_filename}"
    
    presigned_url = generate_presigned_url(
        bucket_name="event-images",
        file_key=file_key,
        expires_in=300
    )
    
    base_url = get_bucket_url("event-images")
    public_url = f"{base_url}/{file_key}"
    
    return {
        "presigned_url": presigned_url,
        "public_url": public_url,
        "file_key": file_key
    }


@router.get(
    "/activities/{activity_id}/survey/results",
    response_model=SurveyStatsResponse,
    status_code=status.HTTP_200_OK,
    summary="설문조사 통계 조회",
    description="설문조사 응답 통계를 조회합니다. (관리자 권한 필요)",
    responses={
        200: {"description": "성공"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"}
    }
)
async def get_survey_stats(
    activity_id: int,
    current_user: dict = Depends(require_admin)
):
    """설문조사 통계 조회 (관리자 전용)"""
    try:
        # 설문조사 확인
        activity_result = supabase.table("activities")\
            .select("config")\
            .eq("id", activity_id)\
            .eq("type", "survey")\
            .eq("is_deleted", False)\
            .single()\
            .execute()
        
        if not activity_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="설문조사를 찾을 수 없습니다"
            )
        
        # 응답 조회
        responses_result = supabase.table("activity_registrations")\
            .select("survey_responses")\
            .eq("activity_id", activity_id)\
            .execute()
        
        total_responses = len(responses_result.data) if responses_result.data else 0
        
        # 통계 집계 (간단한 구현)
        question_stats = []
        config = activity_result.data.get("config", {})
        questions = config.get("questions", [])
        
        for question in questions:
            q_id = str(question["id"])
            q_type = question["type"]
            
            if q_type == "multiple_choice":
                # 객관식: 옵션별 응답 수 집계
                counts = {}
                for resp in responses_result.data:
                    survey_resp = resp.get("survey_responses", {})
                    answer = survey_resp.get(q_id)
                    if answer:
                        counts[answer] = counts.get(answer, 0) + 1
                
                question_stats.append({
                    "question_id": question["id"],
                    "question": question["question"],
                    "type": q_type,
                    "responses": counts
                })
            else:
                # 주관식: 모든 응답 수집
                answers = []
                for resp in responses_result.data:
                    survey_resp = resp.get("survey_responses", {})
                    answer = survey_resp.get(q_id)
                    if answer:
                        answers.append(answer)
                
                question_stats.append({
                    "question_id": question["id"],
                    "question": question["question"],
                    "type": q_type,
                    "responses": answers
                })
        
        return SurveyStatsResponse(
            activity_id=activity_id,
            total_responses=total_responses,
            question_stats=question_stats
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="설문조사 통계 조회 실패"
        )


@router.get(
    "/activities/{activity_id}/demand-survey/stats",
    response_model=DemandSurveyStatsResponse,
    status_code=status.HTTP_200_OK,
    summary="수요조사 통계 조회",
    description="수요조사 응답 통계를 조회합니다. 객관식(select, radio)과 주관식(text, textarea)을 분리하여 제공합니다. (관리자 권한 필요)",
    responses={
        200: {"description": "성공"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "수요조사 없음"}
    }
)
async def get_demand_survey_stats(
    activity_id: int,
    current_user: dict = Depends(require_admin)
):
    """
    수요조사 통계 조회 (관리자 전용)
    
    해당 수요조사의 응답 통계를 객관식/주관식으로 분류하여 반환합니다.
    - 객관식 (select, radio, checkbox): 옵션별 응답 수
    - 주관식 (text, textarea): 모든 응답 목록
    """
    try:
        # 수요조사 확인
        activity_result = supabase.table("activities")\
            .select("form_fields, title, is_anonymous")\
            .eq("id", activity_id)\
            .eq("type", "demand_survey")\
            .eq("is_deleted", False)\
            .single()\
            .execute()
        
        if not activity_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="수요조사를 찾을 수 없습니다"
            )
        
        # 응답 조회
        responses_result = supabase.table("activity_registrations")\
            .select("form_responses, name, student_id, created_at")\
            .eq("activity_id", activity_id)\
            .neq("status", "cancelled")\
            .order("created_at", desc=True)\
            .execute()
        
        total_responses = len(responses_result.data) if responses_result.data else 0
        form_fields = activity_result.data.get("form_fields", [])
        is_anonymous = activity_result.data.get("is_anonymous", True)
        
        # 객관식/주관식 분류
        objective_stats = []  # 객관식 (select, radio, checkbox)
        subjective_stats = []  # 주관식 (text, textarea)
        
        # 객관식 타입
        objective_types = {"select", "radio", "checkbox"}
        # 주관식 타입
        subjective_types = {"text", "textarea", "number", "date"}
        
        for field in form_fields:
            field_name = field.get("name")
            field_label = field.get("label", field_name)
            field_type = field.get("type", "text")
            field_options = field.get("options", [])
            
            if field_type in objective_types:
                # 객관식: 옵션별 응답 수 집계
                option_counts = {opt: 0 for opt in field_options}
                other_count = 0
                
                for resp in (responses_result.data or []):
                    form_resp = resp.get("form_responses", {})
                    answer = form_resp.get(field_name)
                    
                    if answer:
                        # checkbox는 리스트일 수 있음
                        if isinstance(answer, list):
                            for a in answer:
                                if a in option_counts:
                                    option_counts[a] += 1
                                else:
                                    other_count += 1
                        else:
                            if answer in option_counts:
                                option_counts[answer] += 1
                            else:
                                other_count += 1
                
                objective_stats.append({
                    "field_name": field_name,
                    "label": field_label,
                    "type": field_type,
                    "options": field_options,
                    "counts": option_counts,
                    "other_count": other_count
                })
            
            elif field_type in subjective_types:
                # 주관식: 모든 응답 수집
                answers = []
                for resp in (responses_result.data or []):
                    form_resp = resp.get("form_responses", {})
                    answer = form_resp.get(field_name)
                    
                    if answer is not None and str(answer).strip():
                        # 익명 모드일 때는 응답자 정보를 "익명"으로 표시
                        if is_anonymous:
                            respondent = "익명"
                        else:
                            respondent = resp.get("name") or f"학번 {resp.get('student_id', '미상')}"
                        answers.append({
                            "answer": answer,
                            "respondent": respondent,
                            "created_at": resp.get("created_at")
                        })
                
                subjective_stats.append({
                    "field_name": field_name,
                    "label": field_label,
                    "type": field_type,
                    "response_count": len(answers),
                    "responses": answers
                })
        
        return {
            "activity_id": activity_id,
            "title": activity_result.data.get("title"),
            "total_responses": total_responses,
            "objective_questions": objective_stats,
            "subjective_questions": subjective_stats
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="수요조사 통계 조회 실패"
        )


# ============================================================================
# 이미지 관리 API
# ============================================================================

@router.post(
    "/admin/activities/{activity_id}/images",
    status_code=status.HTTP_201_CREATED,
    summary="활동 이미지 추가 (관리자)",
    description="활동에 이미지를 추가합니다 (관리자 권한 필요)",
    responses={
        201: {"description": "이미지 추가 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
async def add_activity_image(
    activity_id: int,
    image: UploadFile = File(...),
    caption: Optional[str] = Form(None),
    display_order: int = Form(0),
    current_user: dict = Depends(require_admin)
):
    """활동 이미지 추가 (관리자 전용)"""
    try:
        # 활동 존재 확인
        check_result = supabase.table("activities")\
            .select("id")\
            .eq("id", activity_id)\
            .eq("is_deleted", False)\
            .single()\
            .execute()
        
        if not check_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="활동을 찾을 수 없습니다"
            )
        
        # 이미지 업로드
        image_url = await upload_file_to_r2(
            file=image,
            bucket_name="activity-images",
            folder=f"activity-{activity_id}",
            allowed_extensions={".jpg", ".jpeg", ".png"},
            max_size_mb=10
        )
        
        # 이미지 정보 저장
        image_data = {
            'activity_id': activity_id,
            'image_url': image_url,
            'display_order': display_order,
            'caption': caption
        }
        
        admin_supabase = get_supabase_admin()
        result = admin_supabase.table('activity_images').insert(image_data).execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="이미지 추가 실패"
            )
        
        return {
            "message": "이미지가 추가되었습니다",
            "image": result.data[0]
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="이미지 추가 실패"
        )


@router.delete(
    "/admin/activities/{activity_id}/images/{image_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="활동 이미지 삭제 (관리자)",
    description="활동의 특정 이미지를 삭제합니다 (관리자 권한 필요)",
    responses={
        204: {"description": "삭제 완료"},
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "권한 없음"},
        404: {"model": ErrorResponse, "description": "이미지 없음"}
    }
)
async def delete_activity_image(
    activity_id: int,
    image_id: int,
    current_user: dict = Depends(require_admin)
):
    """활동 이미지 삭제 (관리자 전용)"""
    admin_supabase = get_supabase_admin()
    try:
        # 이미지 조회
        image_result = admin_supabase.table('activity_images')\
            .select('*')\
            .eq('id', image_id)\
            .eq('activity_id', activity_id)\
            .single()\
            .execute()
        
        if not image_result.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="이미지를 찾을 수 없습니다"
            )
        
        image_url = image_result.data['image_url']
        
        # R2에서 파일 삭제
        try:
            await delete_file_from_r2(image_url, bucket_name="activity-images")
        except Exception:
            # R2 파일 삭제 실패 시 무시 (이미 삭제되었거나 존재하지 않는 경우, DB에서는 삭제)
            pass
        
        # DB에서 삭제
        admin_supabase.table('activity_images').delete().eq('id', image_id).execute()
        
        return None
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="이미지 삭제 실패"
        )


# ============================================================================
# 출석 체크 API
# ============================================================================

@router.get(
    "/{activity_id}/attendance/search",
    response_model=AttendanceInfoResponse,
    summary="학번으로 출석 정보 검색 (공개)",
    description="학번으로 신청 내역을 검색하여 출석 정보를 확인합니다",
    responses={
        404: {"model": ErrorResponse, "description": "신청 내역 없음"}
    }
)
async def search_attendance_by_student_id(
    activity_id: int,
    student_id: str = Query(..., description="학번")
):
    """학번으로 출석 정보 검색 (로그인 불필요)"""
    try:
        # 활동 조회
        activity_result = supabase.table('activities').select('title').eq('id', activity_id).single().execute()
        if not activity_result.data:
            raise HTTPException(status_code=404, detail="활동을 찾을 수 없습니다")
        
        # 학번으로 신청 내역 조회
        registration_result = supabase.table('activity_registrations')\
            .select('id, name, student_id, attended, attended_at')\
            .eq('activity_id', activity_id)\
            .eq('student_id', student_id)\
            .single()\
            .execute()
        
        if not registration_result.data:
            raise HTTPException(status_code=404, detail="해당 학번으로 신청된 내역이 없습니다")
        
        reg = registration_result.data
        
        return AttendanceInfoResponse(
            registration_id=reg['id'],
            activity_title=activity_result.data['title'],
            user_name=reg['name'],
            student_id=reg['student_id'],
            already_attended=reg.get('attended', False),
            attended_at=reg.get('attended_at')
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="출석 정보 조회 실패")


@router.post(
    "/{activity_id}/attend",
    response_model=AttendanceCheckResponse,
    summary="출석 체크 (공개)",
    description="학번으로 출석 체크합니다 (로그인 불필요)",
    responses={
        404: {"model": ErrorResponse, "description": "신청 내역 없음"},
        409: {"model": ErrorResponse, "description": "이미 출석 체크됨"}
    }
)
async def attend_by_student_id(
    activity_id: int,
    body: AttendanceCheckRequest
):
    """학번으로 출석 체크 (로그인 불필요)"""
    try:
        admin_supabase = get_supabase_admin()
        
        # 학번으로 신청 내역 조회 (승인된 신청만)
        registration_result = admin_supabase.table('activity_registrations')\
            .select('id, attended')\
            .eq('activity_id', activity_id)\
            .eq('student_id', body.student_id)\
            .eq('status', 'approved')\
            .maybe_single()\
            .execute()
        
        if not registration_result or not registration_result.data:
            raise HTTPException(status_code=404, detail="해당 학번으로 신청된 내역이 없습니다")
        
        reg = registration_result.data
        
        if reg.get('attended'):
            raise HTTPException(status_code=409, detail="이미 출석 체크가 완료되었습니다")
        
        # 출석 체크 (attended=False 조건으로 race condition 방지)
        from datetime import timezone
        now = datetime.now(timezone.utc)
        
        update_result = admin_supabase.table('activity_registrations').update({
            'attended': True,
            'attended_at': now.isoformat()
        }).eq('id', reg['id']).eq('attended', False).execute()
        
        # 동시 요청으로 이미 처리된 경우
        if not update_result.data:
            raise HTTPException(status_code=409, detail="이미 출석 체크가 완료되었습니다")
        
        return AttendanceCheckResponse(
            registration_id=reg['id'],
            attended_at=now
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="출석 체크 실패")


@router.get(
    "/admin/{activity_id}/attendance",
    response_model=AttendanceListResponse,
    summary="출석 현황 조회 (관리자)",
    description="행사의 전체 출석 현황을 조회합니다",
    responses={
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "관리자 권한 필요"},
        404: {"model": ErrorResponse, "description": "활동 없음"}
    }
)
async def get_attendance_list(
    activity_id: int,
    current_user: dict = Depends(require_admin)
):
    """출석 현황 조회 (관리자)"""
    try:
        admin_supabase = get_supabase_admin()
        
        # 활동 조회
        activity_result = admin_supabase.table('activities').select('title').eq('id', activity_id).single().execute()
        if not activity_result.data:
            raise HTTPException(status_code=404, detail="활동을 찾을 수 없습니다")
        
        # 신청자 목록 조회 (승인된 신청만)
        registrations_result = admin_supabase.table('activity_registrations')\
            .select('id, user_id, name, student_id, phone, created_at, attended, attended_at')\
            .eq('activity_id', activity_id)\
            .eq('status', 'approved')\
            .order('created_at')\
            .execute()
        
        registrations = registrations_result.data or []
        
        # 출석 통계
        total = len(registrations)
        attended_count = sum(1 for r in registrations if r.get('attended'))
        attendance_rate = (attended_count / total * 100) if total > 0 else 0
        
        # 응답 데이터 구성
        items = [
            AttendanceListItem(
                registration_id=r['id'],
                user_id=r.get('user_id'),
                user_name=r['name'],
                student_id=r['student_id'],
                phone=r.get('phone'),
                registered_at=r['created_at'],
                attended=r.get('attended', False),
                attended_at=r.get('attended_at')
            )
            for r in registrations
        ]
        
        return AttendanceListResponse(
            activity_id=activity_id,
            activity_title=activity_result.data['title'],
            total_registrations=total,
            attended_count=attended_count,
            attendance_rate=round(attendance_rate, 1),
            registrations=items
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="출석 현황 조회 실패")


@router.post(
    "/admin/{activity_id}/registrations/{registration_id}/attend",
    response_model=AttendanceCheckResponse,
    summary="출석 체크 (관리자)",
    description="관리자가 특정 참석자의 출석을 체크합니다",
    responses={
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "관리자 권한 필요"},
        404: {"model": ErrorResponse, "description": "신청 내역 없음"}
    }
)
async def admin_mark_attendance(
    activity_id: int,
    registration_id: int,
    current_user: dict = Depends(require_admin)
):
    """관리자가 출석 체크"""
    try:
        admin_supabase = get_supabase_admin()
        
        # 신청 내역 확인 (승인된 신청만)
        reg_result = admin_supabase.table('activity_registrations')\
            .select('id, attended')\
            .eq('id', registration_id)\
            .eq('activity_id', activity_id)\
            .eq('status', 'approved')\
            .single()\
            .execute()
        
        if not reg_result.data:
            raise HTTPException(status_code=404, detail="신청 내역을 찾을 수 없습니다")
        
        if reg_result.data.get('attended'):
            raise HTTPException(status_code=409, detail="이미 출석 체크가 완료되었습니다")
        
        # 출석 체크 (attended=False 조건으로 race condition 방지)
        from datetime import timezone
        now = datetime.now(timezone.utc)
        
        update_result = admin_supabase.table('activity_registrations').update({
            'attended': True,
            'attended_at': now.isoformat()
        }).eq('id', registration_id).eq('attended', False).execute()
        
        if not update_result.data:
            raise HTTPException(status_code=409, detail="이미 출석 체크가 완료되었습니다")
        
        return AttendanceCheckResponse(
            message="출석 처리가 완료되었습니다",
            registration_id=registration_id,
            attended_at=now
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="출석 체크 실패")


@router.delete(
    "/admin/{activity_id}/registrations/{registration_id}/attend",
    status_code=status.HTTP_200_OK,
    summary="출석 취소 (관리자)",
    description="관리자가 특정 참석자의 출석을 취소합니다",
    responses={
        401: {"model": ErrorResponse, "description": "인증 필요"},
        403: {"model": ErrorResponse, "description": "관리자 권한 필요"},
        404: {"model": ErrorResponse, "description": "신청 내역 없음"}
    }
)
async def admin_cancel_attendance(
    activity_id: int,
    registration_id: int,
    current_user: dict = Depends(require_admin)
):
    """관리자가 출석 취소"""
    try:
        admin_supabase = get_supabase_admin()
        
        # 신청 내역 확인
        reg_result = admin_supabase.table('activity_registrations')\
            .select('id')\
            .eq('id', registration_id)\
            .eq('activity_id', activity_id)\
            .single()\
            .execute()
        
        if not reg_result.data:
            raise HTTPException(status_code=404, detail="신청 내역을 찾을 수 없습니다")
        
        # 출석 취소
        admin_supabase.table('activity_registrations').update({
            'attended': False,
            'attended_at': None
        }).eq('id', registration_id).execute()
        
        return {"message": "출석이 취소되었습니다", "registration_id": registration_id}
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="출석 취소 실패")

"""
공용 관리자 계정 생성 스크립트

사용법:
1. .env 파일이 있는 be/ 디렉토리에서 실행
2. python scripts/create_admins.py

주의: 실행 전 비밀번호를 안전한 값으로 변경하세요!
"""
import os
import sys

# be 디렉토리의 모듈을 찾기 위해 경로 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from supabase import create_client

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")  # service_role key 필요

if not SUPABASE_URL or not SUPABASE_KEY:
    print("❌ SUPABASE_URL 또는 SUPABASE_KEY가 설정되지 않았습니다")
    sys.exit(1)

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# ============================================================================
# 관리자 계정 정보 (비밀번호는 반드시 변경하세요!)
# 학번은 8자리 숫자 형식 (00000001 ~ 00000004)
# ============================================================================
admins = [
    {
        "email": "admin1@seoultech.ac.kr",
        "password": "admin001!@",
        "name": "관리자1",
        "student_id": "00000001",
        "department": "관리자",
        "phone": "010-0000-0001",
    },
    {
        "email": "admin2@seoultech.ac.kr",
        "password": "admin002!@",
        "name": "관리자2",
        "student_id": "00000002",
        "department": "관리자",
        "phone": "010-0000-0002",
    },
    {
        "email": "admin3@seoultech.ac.kr",
        "password": "admin003!@",
        "name": "관리자3",
        "student_id": "00000003",
        "department": "관리자",
        "phone": "010-0000-0003",
    },
    {
        "email": "admin4@seoultech.ac.kr",
        "password": "admin004!@",
        "name": "관리자4",
        "student_id": "00000004",
        "department": "관리자",
        "phone": "010-0000-0004",
    },
    {
        "email": "admin5@seoultech.ac.kr",
        "password": "admin005!@",
        "name": "관리자5",
        "student_id": "00000005",
        "department": "관리자",
        "phone": "010-0000-0005",
    },
]


def create_admin(admin: dict):
    """관리자 계정 생성"""
    try:
        # 1. Supabase Auth에 사용자 생성
        auth_response = supabase.auth.admin.create_user({
            "email": admin["email"],
            "password": admin["password"],
            "email_confirm": True
        })
        
        if not auth_response.user:
            print(f"❌ {admin['name']} Auth 생성 실패")
            return False
        
        user_id = auth_response.user.id
        
        # 2. users 테이블에 프로필 추가
        supabase.table("users").insert({
            "id": user_id,
            "email": admin["email"],
            "name": admin["name"],
            "student_id": admin["student_id"],
            "department": admin["department"],
            "phone": admin["phone"],
            "role": "admin",
            "verification_status": "approved",
            "membership_paid": True
        }).execute()
        
        print(f"✅ {admin['name']} ({admin['email']}) - 학번: {admin['student_id']} 생성 완료")
        return True
        
    except Exception as e:
        print(f"❌ {admin['name']} 생성 실패: {str(e)}")
        return False


if __name__ == "__main__":
    print("=" * 50)
    print("공용 관리자 계정 생성")
    print("=" * 50)
    
    success = 0
    for admin in admins:
        if create_admin(admin):
            success += 1
    
    print("=" * 50)
    print(f"완료: {success}/{len(admins)} 계정 생성됨")
    print("=" * 50)
